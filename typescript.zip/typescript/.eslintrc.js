const fs = require('fs');
const path = require('path');

const prettierOptions = JSON.parse(
  fs.readFileSync(path.resolve(__dirname, '.prettierrc'), 'utf8'),
);

module.exports = {
  parser: '@typescript-eslint/parser',
  extends: [
    'plugin:react/recommended',
    'plugin:@typescript-eslint/recommended',
    'prettier/@typescript-eslint',
  ],
  plugins: ['prettier'],
  rules: {
    'object-shorthand': ['error', 'always'],
    'prettier/prettier': ['error', prettierOptions],
    '@typescript-eslint/interface-name-prefix': [
      'error',
      {
        prefixWithI: 'always',
      }
    ],
    '@typescript-eslint/no-use-before-define': 2,
    '@typescript-eslint/explicit-function-return-type': 2,
    '@typescript-eslint/no-non-null-assertion': 2,
    '@typescript-eslint/no-explicit-any': 2,
  },
  overrides: [{
    files: ['**/*.ts?(x)'],
    rules: {
      'prettier/prettier': ['warn', prettierOptions]
    },
  }, ],
  settings: {
    react: {
      version: 'detect', //Tells eslint-plugin-react to automatically detect the version of React to use
    }
  }
};